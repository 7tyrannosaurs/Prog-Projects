#include <iostream>

using namespace std;

class animal {
private:
    char name [50];
    char colour [10];
    int number_of_limbs;
    int age;
public:
    void change_colour (const char*colour_next);
    void print_colour ();
    void change_name (const char*name_next);
    void print_name ();
    void change_age (int age_next);
    void print_age ();
};

