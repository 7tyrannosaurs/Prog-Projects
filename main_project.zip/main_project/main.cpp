#include "mod1.hpp"
#include <iostream>

using namespace std;
int main () {

    struct animal p;
    p.change_colour ("Black");
    p.print_colour ();
    p.change_name ("Berry");
    p.print_name ();
    p.change_age (9720);
    p.print_age ();
    return 0;
}
