#include "mod1.hpp"
    void animal::change_name (const char*name_next) {
        for (int i = 0; i<10; i++)
            name [i] = name_next [i];
    };

    void animal::change_age (int age_next) {
        age = age_next;
    };
