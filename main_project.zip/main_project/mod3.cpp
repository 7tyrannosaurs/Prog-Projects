    #include "mod1.hpp"
    void animal::change_colour (const char*colour_next) {
        for (int i = 0; i<10; i++)
            colour [i] = colour_next [i];
    };
