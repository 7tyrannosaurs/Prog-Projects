#include "mod1.hpp"

    void animal::print_colour () {
        cout << colour;
    };

    void animal::print_name () {
        cout << name << ' ';
    };
    void animal::print_age () {
        cout << age;
    };
